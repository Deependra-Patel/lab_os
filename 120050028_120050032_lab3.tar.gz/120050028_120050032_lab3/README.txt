######################################################
CS 377 - Lab Assignment 3 (B)

30 January 2015
6 pm
Prof D. M. Dhamdhere

######################################################
	
To compile run  'make'
To execute run executable 'jash'

Run 'make clean' to remove executables and .o files

######################################################
	

Team Members:
Deependra Patel 120050032
Rohit Kumar 120050028

Status : working for cd, run, Exit, File executions and Error (6pm). 
Documentation: Included as comments in the code.



Create a single tar-zipped archive of your folder (which you have to submit) —
tar ­zcvf <RollNumber1>_<RollNumber2>_lab3.tgz <RollNumber1>_<RollNumber2>_lab3


######################################################	